﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capa_Entidad
{
    public class ClassEntidad
    {
        public String codigo { get; set; }
        public String titulo { get; set; }
        public String autor { get; set; }
        public String editorial { get; set; }
        public int precio { get; set; }
        public int cantidad { get; set; }
        public String accion { get; set; }

    }
}
